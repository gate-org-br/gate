let template = document.createElement("template");
template.innerHTML = `
	<table><caption></caption><thead></thead><tbody></tbody></table><g-callout class='fill'><slot></slot></g-callout><style data-columns></style>
<style data-element="g-grid">* {
	box-sizing: border-box;
}

caption:empty,
thead:empty,
tbody:empty,
tfoot:empty {
	display: none;
}

:host([empty])>table {
	display: none;
}

:host(:not([empty]))>g-callout {
	display: none;
}


tbody>tr {
	cursor: pointer;
}

tbody>tr:hover>td {
	background-color: var(--hovered, #FFFACD);
}</style>`;
/* global template */

import './g-table.js';
import './g-callout.js';
import './g-properties.js';
import property from './property.js';
import ObjectFilter from './object-filter.js';
import StyledHTMLElement from './styled-html-element.js';

function  parseColumn(spec)
{
	switch (typeof spec)
	{
		case "object":
			if (spec && spec.property)
				return {property: spec.property,
					label: spec.label,
					style: spec.style || ""};
			throw new Error("Invalid column type");

		case "number":
			return {property: `[${spec}]`, style: ""};

		case "string":
			const re = /^((?:[A-Za-z_$][A-Za-z0-9_$]*|\[\d+\])(?:\.(?:[A-Za-z_$][A-Za-z0-9_$]*)|\[\d+\])*)\s*(?::\s*([^;]+?)\s*)?(?:\s*;\s*(left|right|center|justify|\d+(?:\.\d+)?(?:px|%)))?(?:\s*;\s*(left|right|center|justify|\d+(?:\.\d+)?(?:px|%)))?\s*$/;
			const m = re.exec(spec.trim());
			if (!m)
				throw new Error("Formato inválido");

			let property = m[1];
			const label = m[2] || undefined;

			let style = "";
			const aligns = ["left", "right", "center", "justify"];
			[m[3], m[4]].filter(Boolean).filter(e => aligns.includes(e)).forEach(e => style += `text-align:${e};`);
			[m[3], m[4]].filter(Boolean).filter(e => !aligns.includes(e)).forEach(e => style += `width:${e};`);

			return {property, label, style};
		default:
			throw new Error("Invalid column type");
	}
}

function element(content)
{
	switch (typeof content)
	{
		case "string":
			return document.createTextNode(content);
		case "number":
			return document.createTextNode(content);
		case "undefined":
			return document.createTextNode("");
		case "boolean":
			return document.createTextNode(content ? "Sim" : "Não");
		case "function":
			return element(content());
		case "object":
			if (!content)
				return document.createTextNode("");

			if (content instanceof HTMLElement)
				return content;

			if (Array.isArray(content))
			{
				let ul = document.createElement("ul");
				content.forEach(e => ul.appendChild(document.createElement("li")).appendChild(element(e)));
				return ul;
			}

			let properties = document.createElement("g-properties");
			properties.value = content;
			return properties;
	}
}

export default class GGrid extends StyledHTMLElement
{
	constructor()
	{
		super();
		this.setAttribute("empty", "");
		this.shadowRoot.innerHTML = template.innerHTML;
	}

	set caption(value)
	{
		this.shadowRoot.querySelector("caption").textContent = value;
	}

	set header(values)
	{
		const thead = this.shadowRoot.querySelector("thead");
		thead.innerHTML = "";
		const tr = thead.appendChild(document.createElement("tr"));
		values.forEach(e => tr.appendChild(document.createElement("th")).appendChild(element(e)));
	}

	set autoSelect(value)
	{
		if (value)
			this.setAttribute("auto-select", "");
		else
			this.removeAttribute("auto-select");
	}

	get autoSelect()
	{
		return this.hasAttribute("auto-select");
	}

	add(properties, value)
	{
		const row = this.#createRow(properties, value);
		this.shadowRoot.querySelector("tbody").appendChild(row);
		this.removeAttribute("empty");
	}

	set(index, properties, value)
	{
		const tbody = this.shadowRoot.querySelector("tbody");
		const oldRow = tbody.children[index];
		if (!oldRow)
			return;

		const newRow = this.#createRow(properties, value);
		tbody.replaceChild(newRow, oldRow);
	}

	remove(index)
	{
		const tbody = this.shadowRoot.querySelector("tbody");
		const tr = tbody.children[index];
		if (tr)
			tbody.removeChild(tr);

		if (tbody.children.length === 0)
			this.setAttribute("empty", "");
	}

	populate(options = [], { filter, columns = [] } = {})
	{
		this.setAttribute("empty", "");

		const thead = this.shadowRoot.querySelector("thead");
		thead.innerHTML = "";

		const tbody = this.shadowRoot.querySelector("tbody");
		tbody.innerHTML = "";

		if (!options.length)
			return;

		if (!columns.length)
		{
			if (Array.isArray(options[0]))
			{
				const header = options[0];
				options = options.slice(1);
				columns = header.map((label, index) => ({label, property: `[${index}]`}))
					.filter(column => !column.label.startsWith("_"));
			} else
			{
				const keys = Object.keys(options[0]);
				if (keys.length === 2
					&& keys.includes("label")
					&& keys.includes("value"))
					columns = [{property: "value"}];
				else
					columns = keys.filter(k => !k.startsWith("_"))
						.map(label => ({label, property: label}));
			}
		}

		columns = columns.map(parseColumn);

		if (columns.some(col => !col
				|| typeof col.property === "undefined"))
			throw new Error("Column is missing 'property'");

		if (Array.isArray(options[0])
			|| columns.some(column => !column.label)
			|| columns.some(column => column.style))

		{
			if (columns.some(column => column.label))
				this.header = columns.map(column => column.label);
			this.styles = columns.map(c => c.style || "");
			options.forEach(value =>
			{
				const properties = columns.map(column => property(value, column.property));
				if (!filter || ObjectFilter.contains(properties, filter))
					this.add(properties, value);
			});
		} else {
			options.forEach(value =>
			{
				const properties = columns.reduce((obj, column) =>
				{
					obj[column.label] = property(value, column.property);
					return obj;
				}, {});

				if (!filter || ObjectFilter.contains(properties, filter))
					this.add(properties, value);
			});
		}

		if (this.autoSelect && tbody.children.length === 1)
			tbody.children[0].click();
	}

	set styles(values)
	{
		const style = this.shadowRoot.querySelector("style[data-columns]");
		style.textContent = values.map((css, i) => `tr > *:nth-child(${i + 1}) {${css}}`).join('\n');
	}

	static get observedAttributes() {
		return ["draggable", "caption"];
	}

	attributeChangedCallback(name, old, val)
	{
		if (name === "dragabble")
			Array.from(this.shadowRoot.querySelector("tbody").children)
				.forEach(e => e.draggable = this.draggable);
		else
			this.caption = val;
	}

	#createRow(properties, value)
	{
		const tr = document.createElement("tr");

		if (Array.isArray(properties))
			properties.forEach(e => tr.appendChild(document.createElement("td")).appendChild(element(e)));
		else
			tr.appendChild(document.createElement("td")).appendChild(element(properties));

		tr.draggable = this.draggable;

		tr.addEventListener("click", () =>
		{
			const index = Array.from(tr.parentNode.children).indexOf(tr);
			this.dispatchEvent(new CustomEvent('select', {detail: {index, value}}));
		});

		tr.addEventListener("dragover", event => event.preventDefault());

		tr.addEventListener("dragstart", event =>
		{
			const sourceIndex = Array.from(tr.parentNode.children).indexOf(tr);
			event.dataTransfer.setData("text/plain", sourceIndex);
		});

		tr.addEventListener("drop", event =>
		{
			event.preventDefault();
			const sourceIndex = Number(event.dataTransfer.getData("text/plain"));
			const targetIndex = Array.from(tr.parentNode.children).indexOf(tr);
			const rows = Array.from(tr.parentNode.children);
			const sourceRow = rows[sourceIndex];

			if (sourceRow && sourceRow !== tr)
			{
				tr.parentNode.insertBefore(sourceRow, tr);
				this.dispatchEvent(new CustomEvent("move", {detail: {source: sourceIndex, target: targetIndex}}));
			}
		});

		return tr;
	}
}

customElements.define('g-grid', GGrid);