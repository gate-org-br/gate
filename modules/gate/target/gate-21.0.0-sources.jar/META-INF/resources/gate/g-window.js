let template = document.createElement("template");
template.innerHTML = `
<style data-element="g-window">* {
	box-sizing: border-box
}

:host(*) {
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	display: none;
	position: fixed;
	align-items: center;
	justify-content: center;
}

dialog {
	padding: 0;
	height: auto;
	border: none;
	margin: auto;
	display: flex;
	max-width: none;
	max-height: none;
	border-radius: 3px;
	flex-direction: column;
	background-color: var(--main2, #F0F0F0);
	box-shadow: 6px 6px 6px 0px rgba(0, 0, 0, 0.75);
}

dialog>header {
	gap: 8px;
	padding: 8px;
	display: flex;
	font-size: 16px;
	flex-basis: 40px;
	font-weight: bold;
	align-items: center;
	justify-content: space-between;
	border-bottom: 1px solid var(--main3, #DDDDDD);
}

dialog>section {
	padding: 8px;
	flex-grow: 1;
	display: flex;
	overflow: auto;
	align-items: flex-start;
	justify-content: stretch;
	-webkit-overflow-scrolling: touch;
}

dialog>section>fieldset:only-child {
	border: none;
}

dialog>header>label {
	flex-grow: 1;
	display: flex;
	color: inherit;
	font-size: inherit;
	align-items: center;
	justify-content: flex-start;
}

dialog>header>a,
dialog>header>button {
	border: none;
	color: var(--text1, #000000);
	display: flex;
	cursor: pointer;
	font-size: 16px;
	align-items: center;
	text-decoration: none;
	justify-content: center;
	background-color: transparent;
}

dialog>header>a>g-icon,
dialog>header>button>g-icon {
	line-height: 16px;
}

dialog>footer {
	gap: 4px;
	padding: 8px;
	display: flex;
	flex-basis: 60px;
	align-items: stretch;
	justify-content: stretch;
	flex-direction: row-reverse;
	border-top: 1px solid var(--main3, #DDDDDD);
}</style>`;
/* global customElements, template */

import GModal from './g-modal.js';
import stylesheets from './stylesheets.js';
export default class GWindow extends GModal
{
	constructor()
	{
		super();
		this.attachShadow({mode: "open"});
		this.shadowRoot.appendChild(template.content.cloneNode(true));
		stylesheets('table.css', 'input.css', 'fieldset.css')
			.forEach(e => this.shadowRoot.appendChild(e));
	}
};
customElements.define('g-window', GWindow);