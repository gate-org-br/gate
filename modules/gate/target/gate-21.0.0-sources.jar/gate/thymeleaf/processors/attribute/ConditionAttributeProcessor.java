package gate.thymeleaf.processors.attribute;

import gate.adapter.renderer.Renderer;

import gate.adapter.converter.Converter;
import gate.thymeleaf.ELExpressionFactory;
import gate.thymeleaf.Precedence;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;

@ApplicationScoped
public class ConditionAttributeProcessor extends AttributeProcessor
{

	@Inject
	ELExpressionFactory expression;

	public ConditionAttributeProcessor()
	{
		super(null, "condition");
	}

	@Override
	public void process(ITemplateContext context, IProcessableElementTag element, IElementTagStructureHandler handler)
	{
		if ((boolean) expression.create().evaluate(element.getAttributeValue("g:condition")))
		{
			handler.removeAttribute("g:condition");
		} else if (element.hasAttribute("g:otherwise"))
		{
			String otherwise = element.getAttributeValue("g:otherwise");
			otherwise = Renderer.render(expression.create().evaluate(otherwise));
			otherwise = "<g-message class='warning icon'>" + otherwise + "</g-message>";
			handler.replaceWith(otherwise, false);
		} else
			handler.removeElement();
	}

	@Override
	public int getPrecedence()
	{
		return Precedence.HIGH;
	}
}