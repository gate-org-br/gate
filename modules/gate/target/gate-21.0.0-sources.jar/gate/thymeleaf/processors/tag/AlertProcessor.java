package gate.thymeleaf.processors.tag;

import gate.base.Screen;
import gate.converter.Converter;
import gate.thymeleaf.ELExpressionFactory;
import gate.util.Toolkit;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.util.List;
import java.util.StringJoiner;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.context.IWebContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.web.IWebExchange;

@ApplicationScoped
public class AlertProcessor extends TagProcessor
{

	@Inject
	private ELExpressionFactory expression;

	public AlertProcessor()
	{
		super("alert");
	}

	@Override
	public void process(ITemplateContext context, IProcessableElementTag element,
			IElementTagStructureHandler handler)
	{
		@SuppressWarnings("unchecked")
		List<String> messages =
				extract(element, handler, "messages").map(expression.create()::evaluate)
						.map(Toolkit::list).map(e -> (List<String>) e).orElseGet(() -> {
							IWebContext webContext = (IWebContext) context;
							IWebExchange exchange = webContext.getExchange();
							Screen screen = (Screen) exchange.getAttributeValue("screen");
							return screen != null ? screen.getMessages() : List.of();
						});

		if (!messages.isEmpty())
		{
			StringJoiner string = new StringJoiner(System.lineSeparator());

			string.add("<script>");
			string.add("window.addEventListener('load',function(){");
			messages.stream().map(Converter::render).map(e -> e.replace('\'', '"'))
					.map(e -> "alert('" + e + "');").forEach(string::add);
			string.add("let href = window.location.href;");
			string.add("href = href.replace(/messages=[a-zA-Z0-9+\\/=%]*&/, '');");
			string.add("href = href.replace(/&messages=[a-zA-Z0-9+\\/=%]*/, '');");
			string.add("href = href.replace(/[?]messages=[a-zA-Z0-9+\\/=%]*/, '');");
			string.add("window.history.replaceState({}, document.title, href);");
			string.add("});");
			string.add("</script>");

			handler.replaceWith(string.toString(), false);
		} else
			handler.removeElement();
	}
}
