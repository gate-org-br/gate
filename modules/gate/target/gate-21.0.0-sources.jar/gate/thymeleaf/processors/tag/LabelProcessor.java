package gate.thymeleaf.processors.tag;

import gate.adapter.renderer.Renderer;

import gate.annotation.Color;
import gate.base.Screen;
import gate.adapter.converter.Converter;
import gate.lang.property.Property;
import gate.thymeleaf.ELExpressionFactory;
import gate.type.Attributes;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.context.IWebContext;
import org.thymeleaf.exceptions.TemplateProcessingException;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;

import java.util.Optional;

@ApplicationScoped
public class LabelProcessor extends TagProcessor
{

	@Inject
	ELExpressionFactory expression;

	public LabelProcessor()
	{
		super("label");
	}

	@Override
	public void process(ITemplateContext context, IProcessableElementTag element, IElementTagStructureHandler handler)
	{
		var exchange = ((IWebContext) context).getExchange();
		Screen screen = (Screen) exchange.getAttributeValue("screen");

		var property = extract(element, handler, "property")
				.map(e -> Property.getProperty(screen.getClass(), e))
				.orElseThrow(() -> new TemplateProcessingException("Missing required attribute property on g:label"));

		var format = extract(element, handler, "format").orElse(null);
		var empty = extract(element, handler, "empty").orElse(null);

		Attributes attributes = new Attributes();

		var value = property.getValue(screen);

		if (!attributes.containsKey("title"))
		{
			String description = property.getMetadata().description();
			if (description == null || description.isEmpty())
			{
				String displayName = property.getMetadata().name();
				if (displayName != null && !displayName.isEmpty())
					attributes.put("title", displayName);
			} else
				attributes.put("title", description);
		}

		if (!attributes.containsKey("data-tooltip"))
		{
			String tooltip = property.getMetadata().tooltip();
			if (tooltip != null && !tooltip.isEmpty())
				attributes.put("data-tooltip", tooltip);
		}

		if (!attributes.containsKey("style"))
			Color.Extractor.extract(value)
					.or(() -> Optional.ofNullable(property.getMetadata().color()))
					.ifPresent(e -> attributes.put("style", "color: " + e));

		String string = Renderer.render(value, format);
		if (string.isBlank() && empty != null)
			string = Renderer.render(expression.create().evaluate(empty));
		string = string.replaceAll("\\n", "<br/>");

		handler.replaceWith("<label " + attributes + ">" + string + "</label>", true);
	}
}