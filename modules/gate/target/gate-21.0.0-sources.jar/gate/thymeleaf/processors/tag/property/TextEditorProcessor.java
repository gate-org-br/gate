package gate.thymeleaf.processors.tag.property;

import gate.converter.Converter;
import gate.lang.property.Property;
import gate.thymeleaf.ELExpressionFactory;
import gate.type.Attributes;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;

@ApplicationScoped
public class TextEditorProcessor extends PropertyProcessor
{

	@Inject
	ELExpressionFactory expression;

	public TextEditorProcessor()
	{
		super("text-editor");
	}

	@Override
	protected void process(ITemplateContext context, IProcessableElementTag element, IElementTagStructureHandler handler,
		Object screen, Property property, Attributes attributes)
	{

		String value = "";
		if (attributes.containsKey("value"))
			value = Converter.toString(expression.create()
				.evaluate((String) attributes.remove("value")));
		else if (!property.toString().endsWith("[]"))
			value = Converter.toString(property.getValue(screen));

		attributes.put("value", value.replace('"', '\''));

		handler.replaceWith("<g-text-editor " + attributes + "></g-text-editor>", true);
	}
}
