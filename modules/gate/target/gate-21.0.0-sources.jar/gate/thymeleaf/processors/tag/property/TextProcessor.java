package gate.thymeleaf.processors.tag.property;

import gate.adapter.renderer.Renderer;
import gate.lang.property.Property;
import gate.thymeleaf.ELExpressionFactory;
import gate.thymeleaf.Sequence;
import gate.type.Attributes;
import gate.util.Toolkit;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;

import java.util.StringJoiner;
import java.util.function.Function;

@ApplicationScoped
public class TextProcessor extends PropertyProcessor
{

	@Inject
	Sequence sequence;

	@Inject
	ELExpressionFactory expression;

	public TextProcessor()
	{
		super("text");
	}

	@Override
	protected void process(ITemplateContext context, IProcessableElementTag element,
	                       IElementTagStructureHandler handler,
	                       Object screen, Property property, Attributes attributes)
	{
		attributes.put("type", "text");

		if (!attributes.containsKey("data-mask"))
		{
			String mask = property.getMetadata().mask();
			if (mask != null && !mask.isEmpty())
				attributes.put("data-mask", mask);
		}

		if (attributes.containsKey("value"))
			attributes.put("value", property.getConverter().toString(property.getRawType(), expression.create().evaluate((String) attributes.get("value"))));
		else if (!property.toString().endsWith("[]"))
			attributes.put("value", property.getConvertedValue(screen));

		if (attributes.containsKey("options"))
		{
			var options = expression.create().evaluate((String) attributes.remove("options"));
			var labels = extract(element, handler, "labels")
					.map(expression.create()::function).orElse(Function.identity());
			var values = extract(element, handler, "values")
					.map(expression.create()::function).orElse(Function.identity());

			Attributes parameters = new Attributes();
			String id = "datalist-" + sequence.next();
			parameters.put("id", id);
			attributes.put("list", id);

			StringJoiner string = new StringJoiner(System.lineSeparator());
			string.add("<datalist " + parameters + ">");

			for (Object option : Toolkit.iterable(options))
			{
				var label = Renderer.getRenderer(property.getRawType()).render(property.getRawType(), labels.apply(option));
				var value = property.getConverter().toString(property.getRawType(), values.apply(option));
				string.add(String.format("<option data-value='%s'>%s</option>", value, label));
			}

			string.add("</datalist>");

			string.add("<input " + attributes + "/>");
			handler.replaceWith(string.toString(), true);
		} else
			handler.replaceWith("<input " + attributes + "/>", true);
	}

}