ALTER TABLE `gate`.`Uzer` 
CHANGE COLUMN `registration` `registration` DATETIME NOT NULL ;
