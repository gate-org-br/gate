ALTER TABLE `gate`.`Uzer`
ADD COLUMN `code` VARCHAR(32) NULL AFTER `registration`;
