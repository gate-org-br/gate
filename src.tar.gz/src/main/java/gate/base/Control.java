package gate.base;

public class Control extends Base
{

}
