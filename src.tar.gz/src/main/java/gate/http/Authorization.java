package gate.http;

public interface Authorization
{

}
