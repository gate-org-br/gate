export default function compareStyles(element1, element2)
{
	if (!element1 || !element2)
		return false;
	if (element1.tagName !== element2.tagName)
		return false;

	const style1 = element1.getAttribute("style");
	const style2 = element2.getAttribute("style");

	if (style1 === null)
		return style2 === null;
	if (style2 === null)
		return style1 === null;

	const sortedStyle1 = style1.split(";").map(style => style.trim()).filter(Boolean).sort().join(";");
	const sortedStyle2 = style2.split(";").map(style => style.trim()).filter(Boolean).sort().join(";");
	return sortedStyle1 === sortedStyle2;
}