package gate.base;

import gate.annotation.BodyParamExtractor;
import gate.annotation.CookieParamExtractor;
import gate.annotation.HeaderParamExtractor;
import gate.annotation.QueryParamExtractor;
import gate.error.*;
import gate.http.ScreenServletRequest;
import gate.util.Page;
import gate.util.Paginator;
import gate.util.PropertyComparator;
import gate.util.Reflection;
import jakarta.enterprise.inject.spi.Unmanaged;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.CookieParam;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.QueryParam;
import org.slf4j.Logger;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

public abstract class Screen extends Base
{

	private String orderBy;
	private Integer pageSize;
	private Integer pageIndx;
	private List<String> messages;
	private ScreenServletRequest request;
	private HttpServletResponse response;

	@Inject
	Logger logger;

	public static Screen create(Class<Screen> clazz)
	{
		Unmanaged.UnmanagedInstance<Screen> instance = null;
		try
		{
			instance = new Unmanaged<>(clazz).newInstance();
			return instance.produce().inject().postConstruct().get();
		} finally
		{
			if (instance != null)
				instance.preDestroy().dispose();
		}
	}

	public void prepare(ScreenServletRequest request, HttpServletResponse response) throws HttpException
	{
		this.request = request;
		this.response = response;

		var graph = request.getPropertyGraph(getClass());
		graph.get(this, property ->
				request.getParameter(property.getRawType(), property.toString()));
	}

	public Object execute(Method method) throws Throwable
	{
		var parameters = new ArrayList<>();
		for (var parameter : method.getParameters())
		{
			Object value;

			if (parameter.isAnnotationPresent(QueryParam.class))
				value = QueryParamExtractor.extract(getRequest(), parameter);
			else if (parameter.isAnnotationPresent(HeaderParam.class))
				value = HeaderParamExtractor.extract(getRequest(), parameter);
			else if (parameter.isAnnotationPresent(CookieParam.class))
				value = CookieParamExtractor.extract(getRequest(), parameter);
			else
				value = BodyParamExtractor.extract(getRequest(), parameter);

			parameters.add(value);
		}

		try
		{
			return method.invoke(this, parameters.toArray());
		} catch (InvocationTargetException ex)
		{
			throw ex.getCause();
		}
	}

	public Integer getDefaultPageSize()
	{
		return 10;
	}

	public String getModule()
	{
		return getRequest().getParameter("MODULE");
	}

	public String getScreen()
	{
		return getRequest().getParameter("SCREEN");
	}

	public String getAction()
	{
		return getRequest().getParameter("ACTION");
	}

	public ScreenServletRequest getRequest()
	{
		return request;
	}

	public HttpServletResponse getResponse()
	{
		return response;
	}

	public boolean isGET()
	{
		return "GET".equals(request.getMethod());
	}

	public boolean isDELETE()
	{
		return "DELETE".equals(request.getMethod());
	}

	public boolean isPOST()
	{
		return "POST".equals(request.getMethod());
	}

	public boolean isPUT()
	{
		return "PUT".equals(request.getMethod());
	}

	public boolean isPATCH()
	{
		return "PATCH".equals(request.getMethod());
	}

	public String getMethod()
	{
		return request.getMethod().toLowerCase();
	}

	public List<String> getMessages()
	{
		if (messages == null)
			messages = new LinkedList<>();
		return messages;
	}

	public void setMessages(Exception ex)
	{
		setMessages(ex.getMessage());
	}

	public void setMessages(AppException ex)
	{
		setMessages(ex.getMessages());
	}

	public void setMessages(String... messages)
	{
		this.messages = List.of(messages);
	}

	public void setMessages(List<String> messages)
	{
		this.messages = messages;
	}

	public Integer getPageIndx()
	{
		if (pageIndx == null)
			pageIndx = 0;
		return pageIndx;
	}

	public void setPageIndx(Integer pageIndx)
	{
		this.pageIndx = pageIndx;
	}

	public Integer getPageSize()
	{
		if (pageSize == null)
			pageSize = getDefaultPageSize();
		return pageSize;
	}

	public void setPageSize(Integer pageSize)
	{
		this.pageSize = pageSize;
	}

	public String getOrderBy()
	{
		return orderBy;
	}

	public void setOrderBy(String orderBy)
	{
		this.orderBy = orderBy;
	}

	public <R> Page<R> paginate(List<R> data)
	{
		return new Paginator<>(data, getPageSize()).getPage(getPageIndx());
	}

	public <T> List<T> ordenate(List<T> data)
	{
		if (getOrderBy() != null)
			data.sort(new PropertyComparator(getOrderBy()));
		return data;
	}

	@SuppressWarnings("unchecked")
	public static Optional<Class<Screen>> getScreen(String module, String screen)
	{
		try
		{
			return Optional.of(Thread.currentThread().getContextClassLoader().loadClass(screen != null
							? module + "." + screen
							+ "Screen"
							: module + ".Screen"))
					.map(e -> (Class<Screen>) e);
		} catch (ClassNotFoundException ex)
		{
			return Optional.empty();
		}
	}

	public static Optional<Method> getAction(Class<Screen> clazz, String action)
	{
		return Reflection.findMethodByName(clazz, action != null ? "call" + action : "call");
	}

	public static Optional<Method> getAction(String module, String screen, String action)
	{
		return getScreen(module, screen).flatMap(e -> getAction(e, action));
	}
}
