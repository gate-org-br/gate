package gate.handler;

import gate.error.AppError;
import gate.type.mime.MimeDataFile;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@ApplicationScoped
public class MimeDataFileHandler implements Handler
{

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response, Object value) throws AppError
	{
		MimeDataFile mimeDataFile = (MimeDataFile) value;

		response.setContentLength(mimeDataFile.getData().length);

		response.setContentType(mimeDataFile.getContentType().toString());

		response.setHeader("Content-Disposition",
			String.format("attachment; filename=\"%s\"",
				mimeDataFile.getName()));

		try ( OutputStream os = response.getOutputStream())
		{
			os.write(mimeDataFile.getData());
			os.flush();
		} catch (IOException ex)
		{
			throw new UncheckedIOException(ex);
		}
	}
}
