package gate.producer;

import gate.annotation.Current;
import gate.entity.Org;
import gate.sql.Link;
import gate.sql.select.Select;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.Dependent;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.inject.Produces;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.Optional;

/**
 *
 * @author davins
 *
 * Produces an Org object with current organization data.
 *
 */
@ApplicationScoped
public class OrgProducer implements Serializable
{

	@Inject
	private Control control;

	private static final long serialVersionUID = 1L;
	private static final Org DEFAULT = new Org().setOrgID("ORG")
		.setName("Organização");

	@Current
	@Produces
	@Named("organization")
	@RequestScoped
	public Org produce()
	{
		return control.select().orElse(DEFAULT);
	}

	@Dependent
	public static class Control extends gate.base.Control
	{

		public Optional<Org> select()
		{
			try (Dao dao = new Dao())
			{
				return dao.select();
			}
		}

		public static class Dao extends gate.base.Dao
		{

			public Optional<Org> select()
			{
				try (Link link = Link.of("Gate"))
				{
					return Select.expression("orgID")
						.expression("name")
						.expression("description")
						.expression("sun__min")
						.expression("sun__max")
						.expression("mon__min")
						.expression("mon__max")
						.expression("tue__min")
						.expression("tue__max")
						.expression("wed__min")
						.expression("wed__max")
						.expression("thu__min")
						.expression("thu__max")
						.expression("fri__min")
						.expression("fri__max")
						.expression("sat__min")
						.expression("sat__max")
						.from("Org")
						.build()
						.connect(link)
						.fetchEntity(Org.class);
				}
			}
		}
	}
}
