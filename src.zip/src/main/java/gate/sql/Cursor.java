package gate.sql;

import gate.converter.Converter;
import gate.error.ConversionException;
import gate.lang.property.Property;
import gate.lang.property.PropertyGraph;
import gate.sql.fetcher.Fetcher;
import gate.sql.mapper.Mapper;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Enables iteration over the results of a query.
 */
public class Cursor implements AutoCloseable, Fetchable
{

    private int column = 1;
    private final Command command;
    private final ResultSet rs;

    Cursor(Command command, ResultSet rs)
    {
        this.command = command;
        this.rs = rs;
    }

    @Override
    public <T> T fetch(Fetcher<T> fetcher)
    {
        return fetcher.fetch(this);
    }

    @Override
    public <T> Stream<T> stream(Mapper<T> mapper)
    {
        return StreamSupport.stream(new CursorSpliterator<>()
        {
            @Override
            public boolean tryAdvance(Consumer<? super T> action)
            {
                if (!next())
                    return false;

                action.accept(mapper.apply(Cursor.this));

                return true;

            }

        }, false);
    }

    @Override
    public char fetchChar()
    {
        return next() ? getCurrentCharValue() : 0;
    }

    @Override
    public boolean fetchBoolean()
    {
        return next() && getCurrentBooleanValue();
    }

    @Override
    public byte fetchByte()
    {
        return next() ? getCurrentByteValue() : 0;
    }

    @Override
    public short fetchShort()
    {
        return next() ? getCurrentShortValue() : 0;
    }

    @Override
    public int fetchInt()
    {
        return next() ? getCurrentIntValue() : 0;
    }

    @Override
    public long fetchLong()
    {
        return next() ? getCurrentLongValue() : 0;
    }

    @Override
    public float fetchFloat()
    {
        return next() ? getCurrentFloatValue() : 0;
    }

    @Override
    public double fetchDouble()
    {
        return next() ? getCurrentDoubleValue() : 0;
    }

    /**
     * Gets the current column index to be read on the next read operation.
     *
     * @return the current column index to be read on the next read operation
     */
    public int getCurrentColumnIndex()
    {
        return column;
    }

    /**
     * Sets the column index to be read on the next read operation.
     *
     * @param index the column index to be read on the next read operation
     */
    public void setCurrentColumnIndex(int index)
    {
        this.column = index;
    }

    /**
     * Gets the {@link java.sql.ResultSet} associated with this Cursor.
     *
     * @return the {@link java.sql.ResultSet} associated with this Cursor
     */
    public ResultSet getResultSet()
    {
        return rs;
    }

    /**
     * Gets the {@link gate.sql.Command} that generated this Cursor.
     *
     * @return the {@link gate.sql.Command} that generated this Cursor
     */
    public Command getCommand()
    {
        return command;
    }

    /**
     * Checks if there is a next record of the query result to be read.
     *
     * @return true if there is a next record to be read and false otherwise
     */
    public boolean isAfterLast()
    {
        try
        {
            return rs.isAfterLast();
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to determine whether cursor is after the last row", ex);
        }
    }

    /**
     * Move to the next record of the query result.
     *
     * @return true if there is a next record to be moved to, false otherwise
     */
    public boolean next()
    {
        try
        {
            boolean hasNext = rs.next();
            if (hasNext)
                column = 1;
            return hasNext;
        } catch (SQLException e)
        {
            throw new IllegalStateException("Failed to move cursor to the next row", e);
        }
    }

    /**
     * Gets the index of the current record being fetched by this cursor.
     *
     * @return the index of the current record being fetched by this cursor
     */
    public int getCurrentRowIndex()
    {
        try
        {
            return rs.getRow();
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to obtain current row index from cursor", ex);
        }
    }

    /**
     * Checks if the Cursor is closed.
     *
     * @return true if the Cursor is closed and false otherwise
     */
    public boolean isClosed()
    {
        try
        {
            return rs.isClosed();
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to determine whether cursor is closed", ex);
        }

    }

    @Override
    public void close()
    {
        try
        {
            if (!rs.isClosed())
                rs.close();
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to close cursor", ex);
        }
    }

    /**
     * Reads the current column value and moves the column index to the next column.
     *
     * @return the value of the current column
     */
    public Object getCurrentColumnValue()
    {
        return Cursor.this.getValue(column++);
    }

    /**
     * Reads the current column value as an object of the specified type and moves the column index
     * to the next column.
     *
     * @param type type of the object to be read
     * @return the value of the current column as an object of the specified type
     */
    public <T> T getCurrentValue(Class<T> type)
    {
        return getCurrentValue(type, type);
    }

    @SuppressWarnings("unchecked")
    public <T> T getCurrentValue(Class<T> type, Class<?> elementType)
    {
        try
        {
            Converter converter = Converter.getConverter(type);
            // Do not use Class#cast here because primitive classes (e.g. int.class)
            // are not compatible with cast(Object), even when the value is boxed.
            T value = (T) converter.readFromResultSet(getResultSet(), column, elementType);
            column += Math.max(1, converter.getSufixes().size());
            return value;
        } catch (ConversionException | SQLException ex)
        {
            throw new IllegalStateException("Failed to read current value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value.
     *
     * @param columnIndex index of the column to be read
     * @return the value of the specified column
     */
    public Object getValue(int columnIndex)
    {
        try
        {
            Class<?> type =
                    SQLTypeConverter.getJavaType(rs.getMetaData().getColumnType(columnIndex));
            return Converter.getConverter(type).readFromResultSet(rs, columnIndex, type);
        } catch (ConversionException | SQLException ex)
        {
            throw new IllegalStateException("Failed to read value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java byte.
     *
     * @param columnIndex index of the column to be read
     * @return the value of the specified column
     */
    public byte getByteValue(int columnIndex)
    {
        try
        {
            return rs.getByte(columnIndex);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read byte value from cursor", ex);
        }
    }

    /**
     * Reads the current specified column value as a java byte.
     *
     * @return the value of the specified column
     */
    public byte getCurrentByteValue()
    {
        try
        {
            return rs.getByte(column++);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read current byte value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java short.
     *
     * @param columnIndex index of the column to be read
     * @return the value of the specified column
     */
    public short getShortValue(int columnIndex)
    {
        try
        {
            return rs.getShort(columnIndex);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read short value from cursor", ex);
        }
    }

    /**
     * Reads the current specified column value as a java short.
     *
     * @return the value of the specified column
     */
    public short getCurrentShortValue()
    {
        try
        {
            return rs.getShort(column++);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read current short value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java int.
     *
     * @param columnIndex index of the column to be read
     * @return the value of the specified column
     */
    public int getIntValue(int columnIndex)
    {
        try
        {
            return rs.getInt(columnIndex);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read int value from cursor", ex);
        }
    }

    /**
     * Reads the current specified column value as a java int.
     *
     * @return the value of the specified column
     */
    public int getCurrentIntValue()
    {
        try
        {
            return rs.getInt(column++);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read current int value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java long.
     *
     * @param columnIndex index of the column to be read
     * @return the value of the specified column
     */
    public long getLongValue(int columnIndex)
    {
        try
        {
            return rs.getLong(columnIndex);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read long value from cursor", ex);
        }
    }

    /**
     * Reads the current specified column value as a java long.
     *
     * @return the value of the specified column
     */
    public long getCurrentLongValue()
    {
        try
        {
            return rs.getLong(column++);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read current long value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java float.
     *
     * @param columnIndex index of the column to be read
     * @return the value of the specified column
     */
    public float getFloatValue(int columnIndex)
    {
        try
        {
            return rs.getFloat(columnIndex);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read float value from cursor", ex);
        }
    }

    /**
     * Reads the current specified column value as a java float.
     *
     * @return the value of the specified column
     */
    public float getCurrentFloatValue()
    {
        try
        {
            return rs.getFloat(column++);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read current float value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java double.
     *
     * @param columnIndex index of the column to be read
     * @return the value of the specified column
     */
    public double getDoubleValue(int columnIndex)
    {
        try
        {
            return rs.getDouble(columnIndex);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read double value from cursor", ex);
        }
    }

    /**
     * Reads the current specified column value as a java double.
     *
     * @return the value of the specified column
     */
    public double getCurrentDoubleValue()
    {
        try
        {
            return rs.getDouble(column++);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read current double value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java boolean.
     *
     * @param columnIndex index of the column to be read
     * @return the value of the specified column
     */
    public boolean getBooleanValue(int columnIndex)
    {
        try
        {
            return rs.getBoolean(columnIndex);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read boolean value from cursor", ex);
        }
    }

    /**
     * Reads the current specified column value as a java boolean.
     *
     * @return the value of the specified column
     */
    public boolean getCurrentBooleanValue()
    {
        try
        {
            return rs.getBoolean(column++);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read current boolean value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java char.
     *
     * @param columnIndex index of the column to be read
     * @return the value of the specified column
     */
    public char getCharValue(int columnIndex)
    {
        try
        {
            return (char) rs.getInt(columnIndex);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read char value from cursor", ex);
        }
    }

    /**
     * Reads the current specified column value as a java char.
     *
     * @return the value of the specified column
     */
    public char getCurrentCharValue()
    {
        try
        {
            return (char) rs.getInt(column++);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read current char value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as an object of the specified type.
     *
     * @param type        type of the object to be read
     * @param columnIndex index of the column to be read
     * @return the value of the specified column
     */
    @SuppressWarnings("unchecked")
    public <T> T getValue(Class<T> type, int columnIndex)
    {
        try
        {
            return (T) Converter.getConverter(type).readFromResultSet(getResultSet(), columnIndex,
                    type);
        } catch (ConversionException | SQLException e)
        {
            throw new IllegalStateException("Failed to read value from cursor", e);
        }
    }

    /**
     * Reads the specified column value as an object of the specified type.
     *
     * @param <T>         type of the object to be read
     * @param <E>         type of the object elements
     * @param type        type of the object to be read
     * @param elementType type of the object elements
     * @param columnIndex index of the column to be read
     * @return the value of the specified column
     */
    @SuppressWarnings("unchecked")
    public <T, E> T getValue(Class<T> type, Class<E> elementType, int columnIndex)
    {
        try
        {
            return (T) Converter.getConverter(type).readFromResultSet(getResultSet(), columnIndex,
                    elementType);
        } catch (ConversionException | SQLException e)
        {
            throw new IllegalStateException("Failed to read value from cursor", e);
        }
    }

    /**
     * Reads the specified column value as an object of the specified type.
     *
     * @param type       type of the object to be read
     * @param columnName name of the column to be read
     * @return the value of the specified column
     */
    @SuppressWarnings("unchecked")
    public <T> T getValue(Class<T> type, String columnName)
    {
        try
        {
            return (T) Converter.getConverter(type).readFromResultSet(getResultSet(), columnName,
                    type);
        } catch (ConversionException | SQLException e)
        {
            throw new IllegalStateException("Failed to read value from cursor", e);
        }
    }

    /**
     * Reads the specified column value as an object of the specified type.
     *
     * @param <T>         type of the object to be read
     * @param <E>         type of the object elements
     * @param type        type of the object to be read
     * @param elementType type of the object elements
     * @param columnName  name of the column to be read
     * @return the value of the specified column
     */
    @SuppressWarnings("unchecked")
    public <T, E> T getValue(Class<T> type, Class<E> elementType, String columnName)
    {
        try
        {
            return (T) Converter.getConverter(type).readFromResultSet(getResultSet(), columnName,
                    elementType);
        } catch (ConversionException | SQLException e)
        {
            throw new IllegalStateException("Failed to read value from cursor", e);
        }
    }

    /**
     * Reads the specified column value as a java byte.
     *
     * @param columnName name of the column to be read
     * @return the value of the specified column
     */
    public byte getByteValue(String columnName)
    {
        try
        {
            return rs.getByte(columnName);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read byte value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java byte.
     *
     * @param columnName name of the column to be read
     * @return the value of the specified column
     */
    public char getCharValue(String columnName)
    {
        try
        {
            return (char) rs.getInt(columnName);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read char value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java short.
     *
     * @param columnName name of the column to be read
     * @return the value of the specified column
     */
    public short getShortValue(String columnName)
    {
        try
        {
            return rs.getShort(columnName);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read short value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java integer.
     *
     * @param columnName name of the column to be read
     * @return the value of the specified column
     */
    public int getIntValue(String columnName)
    {
        try
        {
            return rs.getInt(columnName);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read int value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java long.
     *
     * @param columnName name of the column to be read
     * @return the value of the specified column
     */
    public long getLongValue(String columnName)
    {
        try
        {
            return rs.getLong(columnName);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read long value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java float.
     *
     * @param columnName name of the column to be read
     * @return the value of the specified column
     */
    public float getFloatValue(String columnName)
    {
        try
        {
            return rs.getFloat(columnName);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read float value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java double.
     *
     * @param columnName name of the column to be read
     * @return the value of the specified column
     */
    public double getDoubleValue(String columnName)
    {
        try
        {
            return rs.getDouble(columnName);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read double value from cursor", ex);
        }
    }

    /**
     * Reads the specified column value as a java boolean.
     *
     * @param columnName name of the column to be read
     * @return the value of the specified column
     */
    public boolean getBooleanValue(String columnName)
    {
        try
        {
            return rs.getBoolean(columnName);
        } catch (SQLException ex)
        {
            throw new IllegalStateException("Failed to read boolean value from cursor", ex);
        }
    }

    /**
     * Gets the number of columns of the cursor.
     *
     * @return the number of columns associated with this cursor
     */
    public int getColumnCount()
    {
        try
        {
            return rs.getMetaData().getColumnCount();
        } catch (SQLException e)
        {
            throw new IllegalStateException("Failed to obtain column count from cursor", e);
        }

    }

    /**
     * Gets the names of columns of the cursor.
     *
     * @return a java list with the names of the columns associated with this cursor
     */
    public List<String> getColumnNames()
    {
        try
        {
            ResultSetMetaData rsmd = getResultSet().getMetaData();
            List<String> names = new ArrayList<>(rsmd.getColumnCount());
            for (int i = 0; i < rsmd.getColumnCount(); i++)
                names.add(rsmd.getColumnLabel(i + 1));
            return names;
        } catch (SQLException e)
        {
            throw new IllegalStateException("Failed to obtain column names from cursor", e);
        }
    }

    /**
     * Gets the default java types of the columns of the cursor.
     *
     * @return a java list with the default java types of the columns of the cursor
     */
    public List<Class<?>> getColumnTypes()
    {
        try
        {
            ResultSetMetaData rsmd = getResultSet().getMetaData();
            List<Class<?>> types = new ArrayList<>(rsmd.getColumnCount());
            for (int i = 0; i < rsmd.getColumnCount(); i++)
                types.add(SQLTypeConverter.getJavaType(rsmd.getColumnType(i + 1)));
            return types;
        } catch (SQLException e)
        {
            throw new IllegalStateException("Failed to obtain column types from cursor", e);
        }
    }

    /**
     * Gets the values of all the columns of the cursor as a List.
     *
     * @return a java list with the values of the columns of the cursor
     */
    public List<Object> getColumnValues()
    {
        int count = getColumnCount();
        List<Object> result = new ArrayList<>();
        for (int i = 0; i < count; i++)
            result.add(getValue(i + 1));
        return result;
    }

    public List<String> getPropertyNames()
    {
        return getColumnNames().stream()
                .map(e -> e.contains(Converter.SEPARATOR) ? e.split(Converter.SEPARATOR)[0] : e)
                .map(e -> e.contains("$") ? e.replaceAll("[$]", ".") : e).distinct()
                .collect(Collectors.toList());
    }

    public Map<String, Class<?>> getMetaData()
    {
        try
        {
            Map<String, Class<?>> result = new LinkedHashMap<>();
            ResultSetMetaData rsmd = getResultSet().getMetaData();
            int count = rsmd.getColumnCount();
            for (int i = 1; i <= count; i++)
                result.put(rsmd.getColumnLabel(i),
                        SQLTypeConverter.getJavaType(rsmd.getColumnType(i)));
            return result;
        } catch (SQLException e)
        {
            throw new IllegalStateException("Failed to obtain metadata from cursor", e);
        }
    }

    public List<Property> getProperties(Class<?> type)
    {
        return getColumnNames().stream()
                .map(e -> e.contains(Converter.SEPARATOR) ? e.split("_")[0] : e)
                .map(e -> e.contains("$") ? e.replaceAll("[$]", ".") : e)
                .map(e -> Property.getProperty(type, e)).distinct().collect(Collectors.toList());
    }

    /**
     * Reads the current row as a java object of the specified type with it's property values
     * matched to their respective column values.
     *
     * @param type type of the entity to be read
     * @return the current row as a java object of the specified type with it's property values
     * matched to their respective column values.
     */
    public <T> T getEntity(Class<T> type)
    {
        return getEntity(getPropertyGraph(type));
    }

    /**
     * Creates a PropertyGraph for the specified type with all the columns
     *
     * @param type type of the entity to be read
     * @return A PropertyGraph for the type with all columns returned by the cursor
     */
    public <T> PropertyGraph<T> getPropertyGraph(Class<T> type)
    {
        return PropertyGraph.of(type, getPropertyNames());
    }

    /**
     * Reads the current row as a java object of the specified type with its property values
     * matched to their respective column values.
     *
     * @param graph PropertyGraph of the entity to be read
     * @return the current row as a java object of the specified type with its property values
     * matched to their respective column values.
     */
    @SuppressWarnings("unchecked")
    public <T> T getEntity(PropertyGraph<T> graph)
            throws ConversionException
    {
        return (T) graph.get(null, property ->
        {
            if (property.getRawType() == boolean.class)
                return getBooleanValue(property.toString());
            else if (property.getRawType() == char.class)
                return getCharValue(property.toString());
            else if (property.getRawType() == byte.class)
                return getByteValue(property.toString());
            else if (property.getRawType() == short.class)
                return getShortValue(property.toString());
            else if (property.getRawType() == int.class)
                return getIntValue(property.toString());
            else if (property.getRawType() == long.class)
                return getLongValue(property.toString());
            else if (property.getRawType() == float.class)
                return getFloatValue(property.toString());
            else if (property.getRawType() == double.class)
                return getDoubleValue(property.toString());
            else if (Collection.class.isAssignableFrom(property.getRawType()))
                return getValue(property.getRawType(),
                        property.getElementRawType(), property.toString());
            else
                return getValue(property.getRawType(), property.toString());
        });
    }
}
